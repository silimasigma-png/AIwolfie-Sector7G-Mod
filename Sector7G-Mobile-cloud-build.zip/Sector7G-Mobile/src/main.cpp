// C++, src/main.cpp, Geode SDK v5.11.2, Geometry Dash Android 2.2081
#include <Geode/Geode.hpp>
#include <Geode/modify/MenuLayer.hpp>

using namespace geode::prelude;

namespace {
    constexpr char GLOW_KEY[] = "glow_mode";
    constexpr char CLEAN_KEY[] = "clean_ui";

    class SectorPanel final : public CCLayerColor {
    protected:
        CCMenuItemFont* m_glowButton = nullptr;
        CCMenuItemFont* m_cleanButton = nullptr;

        void refreshButtons() {
            bool glow = Mod::get()->getSavedValue<bool>(GLOW_KEY, true);
            bool clean = Mod::get()->getSavedValue<bool>(CLEAN_KEY, true);

            m_glowButton->setString(glow ? "GLOW MODE: ON" : "GLOW MODE: OFF");
            m_cleanButton->setString(clean ? "CLEAN UI: ON" : "CLEAN UI: OFF");

            m_glowButton->setColor(glow ? ccc3(150, 255, 65) : ccc3(170, 170, 170));
            m_cleanButton->setColor(clean ? ccc3(150, 255, 65) : ccc3(170, 170, 170));
        }

        void onGlow(CCObject*) {
            bool old = Mod::get()->getSavedValue<bool>(GLOW_KEY, true);
            Mod::get()->setSavedValue<bool>(GLOW_KEY, !old);
            refreshButtons();
        }

        void onClean(CCObject*) {
            bool old = Mod::get()->getSavedValue<bool>(CLEAN_KEY, true);
            Mod::get()->setSavedValue<bool>(CLEAN_KEY, !old);
            refreshButtons();
        }

        void onChatGPT(CCObject*) {
            FLAlertLayer::create(
                "CHATGPT",
                "SECTOR 7G assistant panel\n\nThis button is a local demo. "
                "It does not connect to an AI service or send game data.",
                "CLOSE"
            )->show();
        }

        void onDecorate(CCObject*) {
            FLAlertLayer::create(
                "DECORATE",
                "Decoration tools are reserved for the next module. "
                "This build includes the mobile menu and saved visual settings.",
                "OK"
            )->show();
        }

        void onClose(CCObject*) {
            this->removeFromParentAndCleanup(true);
        }

    public:
        bool init() {
            auto win = CCDirector::sharedDirector()->getWinSize();
            if (!CCLayerColor::initWithColor({ 7, 8, 35, 238 })) return false;

            auto title = CCLabelBMFont::create("SECTOR 7G", "bigFont.fnt");
            title->setScale(0.72f);
            title->setColor(ccc3(175, 255, 90));
            title->setPosition({ win.width / 2, win.height * 0.82f });
            this->addChild(title);

            auto subtitle = CCLabelBMFont::create("MOBILE CONTROL CENTER", "goldFont.fnt");
            subtitle->setScale(0.42f);
            subtitle->setPosition({ win.width / 2, win.height * 0.75f });
            this->addChild(subtitle);

            auto menu = CCMenu::create();
            menu->setPosition({ win.width / 2, win.height * 0.48f });
            this->addChild(menu);

            m_glowButton = CCMenuItemFont::create("GLOW MODE: ON", this, menu_selector(SectorPanel::onGlow));
            m_cleanButton = CCMenuItemFont::create("CLEAN UI: ON", this, menu_selector(SectorPanel::onClean));
            auto chat = CCMenuItemFont::create("CHATGPT", this, menu_selector(SectorPanel::onChatGPT));
            auto decorate = CCMenuItemFont::create("DECORATE", this, menu_selector(SectorPanel::onDecorate));
            auto close = CCMenuItemFont::create("CLOSE", this, menu_selector(SectorPanel::onClose));

            CCMenuItemFont* items[] = { m_glowButton, m_cleanButton, chat, decorate, close };
            for (int i = 0; i < 5; ++i) {
                items[i]->setScale(0.72f);
                items[i]->setColor(ccc3(150, 255, 65));
                items[i]->setPosition({ 0, 88.0f - i * 43.0f });
                menu->addChild(items[i]);
            }

            refreshButtons();
            return true;
        }

        static SectorPanel* create() {
            auto ret = new SectorPanel();
            if (ret && ret->init()) {
                ret->autorelease();
                return ret;
            }
            CC_SAFE_DELETE(ret);
            return nullptr;
        }
    };
}

class $modify(Sector7GMenuLayer, MenuLayer) {
    bool init() {
        if (!MenuLayer::init()) return false;

        auto win = CCDirector::sharedDirector()->getWinSize();
        auto item = CCMenuItemFont::create(
            "SECTOR 7G",
            this,
            menu_selector(Sector7GMenuLayer::openSectorPanel)
        );
        item->setScale(0.55f);
        item->setColor(ccc3(150, 255, 65));

        auto menu = CCMenu::create(item, nullptr);
        menu->setPosition({ win.width / 2, 34.0f });
        this->addChild(menu, 1000);
        return true;
    }

    void openSectorPanel(CCObject*) {
        if (auto scene = CCDirector::sharedDirector()->getRunningScene()) {
            scene->addChild(SectorPanel::create(), 9999);
        }
    }
};
