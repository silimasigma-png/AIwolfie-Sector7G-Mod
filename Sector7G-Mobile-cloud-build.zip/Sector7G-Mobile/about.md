# Sector 7G Mobile

A neon green / midnight blue touch-friendly control panel for Geometry Dash mobile.

## Included
- In-game Sector 7G launcher button on the main menu
- Scalable overlay panel
- Saved Glow Mode and Clean UI toggles
- ChatGPT demo panel
- Decoration placeholder panel

The ChatGPT panel is intentionally local-only; it does not call an AI API.
The visual toggles save their state but do not yet alter Geometry Dash rendering.
