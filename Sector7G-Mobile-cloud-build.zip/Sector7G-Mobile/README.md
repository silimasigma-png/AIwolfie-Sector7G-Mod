# Sector 7G Mobile — source project

**Target:** Geode v5.11.2, Geometry Dash Android 2.2081.

This is the complete starter source project. It is not a precompiled `.geode` package.

## Build on a computer

1. Install the Geode CLI and Android NDK.
2. Install Android Geode binaries:
   ```sh
   geode sdk install
   geode sdk install-binaries -p android64
   ```
   For a 32-bit Android device, use `android32` instead.
3. From this project directory, build:
   ```sh
   geode build -p android64
   ```
4. Copy the resulting `.geode` file from `build-android64` to:
   `/storage/emulated/0/Android/media/com.geode.launcher/game/geode/mods/`
5. Restart Geometry Dash.

## In game

Tap **SECTOR 7G** on the main menu to open the panel.

## Important scope

The panel, touch buttons, and persistent settings are implemented. The two toggles currently store their preferences; they do not yet patch the game's glow renderer or global UI. The ChatGPT button is a local demo panel, not an AI connection. The decoration button explains that its editor module is not included yet.
